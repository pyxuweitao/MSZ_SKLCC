xmlfile = "<?xml version='1.0'?><xml><re><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /><record no='00310' name='陈美华' count='798' time='41934.9' per_time='0.002442' /><record no='00965' name='王素红' count='668' time='35813.9' per_time='0.002442' /><record no='01475' name='陈兆英' count='371' time='32267.57' per_time='0.002442' /><record no='10117' name='史燕雯' count='201' time='16395.22' per_time='0.002442' /><record no='10148' name='翁丽芬' count='455' time='23910.25' per_time='0.002442' /><record no='10199' name='张迎阳' count='149' time='7572.32' per_time='0.002442' /><record no='10257' name='王洁' count='92' time='3749.68' per_time='0.002442' /></re></xml>";
selected_flag = false;

var record_data = [];
window.onload = function () {
    $(".form-control").datetimepicker({
        format: 'yyyy-mm-dd',
        language: 'zh-CN',
        todayHighlight: 'true',
        minView: 2
    });
}


function getint(input) {
    var temp_int = '';
    for (var i = 0; i < input.length; i++) {
        if (parseInt(input.slice(i, i + 1)) || parseInt(input.slice(i, i + 1)) == 0) {
            temp_int += parseInt(input.slice(i, i + 1));
        }
    }
    return parseInt(temp_int);
}


function flush_info() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            // alert(xmlhttp.responseText.toString());
            xmlfile = xmlhttp.responseText.toString();
            //alert(xmlfile);
            build_page(xmlfile);
        }
    }
    var start = getint(document.getElementById("start_time").value).toString();
    var end = getint(document.getElementById("end_time").value).toString();
    //var dep = document.getElementById("department_hint").innerHTML;
    xmlhttp.open("GET", '/flush_form_0?start='+start+'&end='+end, true);//TODO: 服务器端不再判别部门，直接返回全部数据
    xmlhttp.send();
    return;
}

function onclickconfirm() {
    var start = getint(document.getElementById("start_time").value);
    var end = getint(document.getElementById("end_time").value);
    if (end >= start) {
        flush_info();
        //build_page(xmlfile);
    } else {
        alert('日期选择有误');
    }
}


var record = function (no, name, count, time, per_time) {
    this.no = no;
    this.name = name;
    this.count = count;
    this.time = time;
    this.per_time = per_time;
    this.total = (parseFloat(per_time) * parseFloat(time)).toString();
    num = this.total;
    num = num.slice(0, num.lastIndexOf('.') + 3);//采用了去尾法
    this.total = num;
}


function flush() {
    document.getElementById("content").innerHTML = '';
    for (var i = 0; i < record_data.length; i++) {
        var row = document.createElement("tr");
        var cell = document.createElement("td");
        cell.innerHTML = record_data[i].no;
        row.appendChild(cell);
        cell = document.createElement("td");
        cell.innerHTML = record_data[i].name;
        row.appendChild(cell);
        cell = document.createElement("td");
        cell.innerHTML = record_data[i].count;
        row.appendChild(cell);
        cell = document.createElement("td");
        cell.innerHTML = record_data[i].time;
        row.appendChild(cell);
        cell = document.createElement("td");
        cell.innerHTML = record_data[i].per_time;
        row.appendChild(cell);
        cell = document.createElement("td");
        cell.innerHTML = record_data[i].total;
        row.appendChild(cell);
        document.getElementById("content").appendChild(row);
    }
}


function build_page(info) {
    var domParser = new DOMParser();
    record_data = [];
    var xmlDoc = domParser.parseFromString(info, 'text/xml');
    var records = xmlDoc.getElementsByTagName("record");
    for (var i = 0; i < records.length; i++) {
        record_data[record_data.length] = new record(records[i].getAttribute("no"), records[i].getAttribute("name"), records[i].getAttribute("count"), records[i].getAttribute("time"), records[i].getAttribute("per_time"));
    }
    flush();
}

function order_by_no(input) {
    var state = input.getAttribute("state");
    // alert('g');
    if (state == '0') {
        // alert('0');
        record_data.sort(function (x, y) {
            return parseInt(y.no) - parseInt(x.no);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    } else if (state == '1') {
        record_data.sort(function (x, y) {
            return parseInt(x.no) - parseInt(y.no);
        });
        input.setAttribute('state', '-1');
        //input.innerHTML = '工号'+'↑';
    } else {
        record_data.sort(function (x, y) {
            return parseInt(y.no) - parseInt(x.no);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    }
    flush();
}

function order_by_count(input) {
    var state = input.getAttribute("state");
    // alert('g');
    if (state == '0') {
        //alert('0');
        record_data.sort(function (x, y) {
            return parseInt(y.count) - parseInt(x.count);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    } else if (state == '1') {
        record_data.sort(function (x, y) {
            return parseInt(x.count) - parseInt(y.count);
        });
        input.setAttribute('state', '-1');
        //input.innerHTML = '工号'+'↑';
    } else {
        record_data.sort(function (x, y) {
            return parseInt(y.count) - parseInt(x.count);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    }
    flush();
}

function order_by_time(input) {
    var state = input.getAttribute("state");
    // alert('g');
    if (state == '0') {
        //alert('0');
        record_data.sort(function (x, y) {
            return parseFloat(y.time) - parseFloat(x.time);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    } else if (state == '1') {
        record_data.sort(function (x, y) {
            return parseFloat(x.time) - parseFloat(y.time);
        });
        input.setAttribute('state', '-1');
        //input.innerHTML = '工号'+'↑';
    } else {
        record_data.sort(function (x, y) {
            return parseFloat(y.time) - parseFloat(x.time);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    }
    flush();
}


function order_by_total(input) {
    var state = input.getAttribute("state");
    // alert('g');
    if (state == '0') {
        //alert('0');
        record_data.sort(function (x, y) {
            return parseFloat(y.total) - parseFloat(x.total);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    } else if (state == '1') {
        record_data.sort(function (x, y) {
            return parseFloat(x.total) - parseFloat(y.total);
        });
        input.setAttribute('state', '-1');
        //input.innerHTML = '工号'+'↑';
    } else {
        record_data.sort(function (x, y) {
            return parseFloat(y.total) - parseFloat(x.total);
        });
        input.setAttribute('state', '1');
        //input.innerHTML = '工号'+'↓';
    }
    flush();
}

function onclickmonth(input) {
    var year = (new Date()).getFullYear();
    document.getElementById("drop_hint").innerHTML = input.innerHTML;
    var start = document.getElementById("start_time");
    var end = document.getElementById("end_time");
    var month = input.getAttribute("value");
    switch (month) {
        case '1':
            start.value = year + '-' + '01' + '-01';
            end.value = year + '-' + '01' + '-31';
            break;
        case '2':
            start.value = year + '-' + '02' + '-01';
            end.value = year + '-' + '02' + '-29';
            break;
        case '3':
            start.value = year + '-' + '03' + '-01';
            end.value = year + '-' + '03' + '-31';
            break;
        case '4':
            start.value = year + '-' + '04' + '-01';
            end.value = year + '-' + '04' + '-30';
            break;
        case '5':
            start.value = year + '-' + '05' + '-01';
            end.value = year + '-' + '05' + '-31';
            break;
        case '6':
            start.value = year + '-' + '06' + '-01';
            end.value = year + '-' + '06' + '-30';
            break;
        case '7':
            start.value = year + '-' + '07' + '-01';
            end.value = year + '-' + '07' + '-31';
            break;
        case '8':
            start.value = year + '-' + '08' + '-01';
            end.value = year + '-' + '08' + '-31';
            break;
        case '9':
            start.value = year + '-' + '09' + '-01';
            end.value = year + '-' + '09' + '-30';
            break;
        case '10':
            start.value = year + '-' + '10' + '-01';
            end.value = year + '-' + '10' + '-31';
            break;
        case '11':
            start.value = year + '-' + '11' + '-01';
            end.value = year + '-' + '11' + '-30';
            break;
        case '12':
            start.value = year + '-' + '12' + '-01';
            end.value = year + '-' + '12' + '-31';
            break;
    }
    document.getElementById("confirm").click();
}

function onclickdepart(input) {
    document.getElementById("department_hint").innerHTML = input.innerHTML;
    selected_flag = true;
}